<?php
//test_yaml
/*$ndocs = 0;

 // create curl resource
        $ch = curl_init();

        // set url
        curl_setopt($ch, CURLOPT_URL, 's.wbrm/wbrmspm/testyaml.json');

        curl_setopt($ch, CURLOPT_HEADER, 'Content-Type: application/json');

        //return the transfer as a string
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        // $output contains the output string
        $output = curl_exec($ch);

        // close curl resource to free up system resources
        curl_close($ch);     


*/
 $jsonIterator = new RecursiveIteratorIterator(
    new RecursiveArrayIterator(json_decode(file_get_contents("testyaml.json"), TRUE)),
    RecursiveIteratorIterator::SELF_FIRST);

		print_r($jsonIterator);


?>