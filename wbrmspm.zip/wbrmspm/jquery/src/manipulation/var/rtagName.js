define( function() {
	return ( /<([\w:-]+)/ );
} );
